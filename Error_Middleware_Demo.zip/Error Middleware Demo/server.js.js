const express = require('express');
const app = express();
const PORT = 3000;

// Subtask 2.1: Enable JSON parsing
app.use(express.json());

// --- Step 2.2 & 4.1: Demo Routes ---

// Success Route
app.get('/success', (req, res) => {
    res.status(200).json({
        success: true,
        message: "This is a normal, successful response."
    });
});

// Intentional Error Route
app.get('/error', (req, res) => {
    // Manually throwing an error to test the middleware
    const err = new Error("This is a forced test error!");
    err.status = 500;
    throw err; 
});

// Another Error Route (Simulating a "Bad Request")
app.get('/bad-request', (req, res, next) => {
    const err = new Error("Invalid input provided.");
    err.status = 400;
    next(err); // Passing error to middleware using next()
});

// --- Step 5.2: Handle Unknown Routes (404) ---
// This middleware runs if NO other routes above matched
app.use((req, res, next) => {
    const err = new Error("Route not found");
    err.status = 404;
    next(err);
});

// --- Step 3: Global Error Middleware ---
/**
 * Subtask 3.1: Custom Error Middleware
 * Express recognizes this as an error handler because it has 4 parameters.
 */
app.use((err, req, res, next) => {
    // Subtask 4.2: Structured Error Response
    const statusCode = err.status || 500;
    
    console.error(`[Error Log]: ${err.message}`); // Internal logging

    res.status(statusCode).json({
        success: false,
        status: statusCode,
        message: err.message || "Internal Server Error"
    });
});

// Subtask 2.1: Start Server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});