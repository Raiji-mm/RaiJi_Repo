import React from 'react';
import UserCard from './UserCard';
import Welcome from './Welcome';

function App() {
  return (
    <div>
      <Welcome />
      <h1>User Directory</h1>
      <UserCard name="Eloi" email="eloi@gmail.com" />
      <UserCard name="Aki" email="aki@gmail.com" />
    </div>
  );
}

export default App;
