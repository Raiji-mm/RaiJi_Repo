# React JSX Lab

This project is a hands-on lab exercise for creating React components using JSX syntax.

## Components

- **App** – Main application component that renders the User Directory.
- **Welcome** – Displays a greeting heading.
- **UserCard** – Displays a user's name and email inside a styled card.

## Setup & Running

1. Install dependencies:
   ```bash
   npm install
   ```

2. Build the project (transpiles JSX via Babel):
   ```bash
   npm run build
   ```

3. Open `public/index.html` in your browser to view the app.

## Challenges

- Remembering to add `import React from 'react'` in every JSX file when using the classic Babel JSX transform.
- Making sure all components are imported and used in `App.jsx`.
