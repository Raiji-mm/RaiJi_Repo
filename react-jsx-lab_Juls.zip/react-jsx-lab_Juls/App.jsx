import UserCard from "./UserCard";

function App() {
  return (
    <div>
      <h1>User Directory</h1>
      <UserCard name="Eloi" email="eloi@gmail.com" />
      <UserCard name="Aki" email="aki@gmail.com" />
    </div>
  );
}

export default App;